# Release Evidence Summary

- runId: run-20260716-050127
- generatedAtUtc: 2026-07-20T01:31:42.278119+00:00
- firewallDeclared: False
- avdHostPoolDeclared: False
- enforcementMode: runner-pre-filter
- requestedAllowedCategories: ['azure.networkBundle']
- effectiveAllowedCategories: ['azure.networkBundle']
- runtimePlatform: Windows-10-10.0.26200-SP0
